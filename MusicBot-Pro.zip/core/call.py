from pytgcalls import PyTgCalls
from pyrogram import Client
from config import API_ID, API_HASH, SESSION

app = Client(SESSION, api_id=API_ID, api_hash=API_HASH)
call = PyTgCalls(app)

async def play(chat_id, stream_url):
    await call.join_group_call(chat_id, stream_url)

async def stop(chat_id):
    await call.leave_group_call(chat_id)
