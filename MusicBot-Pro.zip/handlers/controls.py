from pyrogram import filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from main import app
from core.call import stop

@app.on_message(filters.command("controls"))
async def controls(client, message):
    buttons = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("⏸️ Pause", callback_data="pause"),
            InlineKeyboardButton("▶️ Resume", callback_data="resume"),
        ],
        [
            InlineKeyboardButton("⏹️ Stop", callback_data="stop")
        ]
    ])

    await message.reply("🎛️ التحكم:", reply_markup=buttons)

@app.on_callback_query()
async def callbacks(client, query):
    if query.data == "stop":
        await stop(query.message.chat.id)
        await query.message.edit("⏹️ تم الإيقاف")
