from pyrogram import filters
from main import app
from utils.stream import get_stream
from utils.queue import add
from core.call import play

@app.on_message(filters.command("play"))
async def play_music(client, message):
    if len(message.command) < 2:
        return await message.reply("اكتب اسم الأغنية")

    query = " ".join(message.command[1:])
    msg = await message.reply("🔎 جاري البحث...")

    url, title = get_stream(query)
    add(message.chat.id, url)

    await play(message.chat.id, url)

    await msg.edit(f"🎧 يتم التشغيل: {title}")
